public interface FlyweightIntr {
  public String getNameFac();
  public String getLocality();
  public String getAddress();
  public String getNeighbourhood();
  public String getCoordinates();
  public void print(String name, String code);
}
